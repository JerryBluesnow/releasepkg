

DROP TABLE IF EXISTS `obj_basic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obj_basic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` char(8) DEFAULT NULL,
  `obj_id` varchar(64) DEFAULT NULL,
  `ship_name` varchar(40) DEFAULT NULL,
  `ais_mmsi` char(16) DEFAULT NULL,
  `cdma_phone` char(16) DEFAULT NULL,
  `bd_id` char(16) DEFAULT NULL,
  `ship_type` varchar(40) DEFAULT NULL,
  `ship_no` char(16) DEFAULT NULL,
  `dist_ship_district` varchar(40) DEFAULT NULL,
  `ship_port` varchar(40) DEFAULT NULL,
  `ship_length` char(8) DEFAULT NULL,
  `ship_width` char(8) DEFAULT NULL,
  `ship_deep` char(8) DEFAULT NULL,
  `ship_tot_ton` char(8) DEFAULT NULL,
  `ship_net_ton` char(8) DEFAULT NULL,
  `ship_tot_power` char(8) DEFAULT NULL,
  `dict_ship_material` varchar(40) DEFAULT NULL,
  `ship_build_comp_date` char(24) DEFAULT NULL,
  `owner_name` varchar(40) DEFAULT NULL,
  `owner_addr` varchar(60) DEFAULT NULL,
  `owner_tel` char(16) DEFAULT NULL,
  `fishing_permit_period_date` char(24) DEFAULT NULL,
  `fishing_permit_number` char(24) DEFAULT NULL,
  `vessel_cert_period_date` char(24) DEFAULT NULL,
  `vessel_cert_number` char(16) DEFAULT NULL,
  `register_period_date` char(24) DEFAULT NULL,
  `register_number` varchar(60) DEFAULT NULL,
  `TERMINAL_PHONE` char(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `obj_id` (`obj_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40107 DEFAULT CHARSET=latin1;




LOCK TABLES `obj_basic` WRITE;
/*!40000 ALTER TABLE `obj_basic` DISABLE KEYS */;
/*!40000 ALTER TABLE `obj_basic` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `obj_com`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obj_com` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `TERMINAL_PHONE` char(12) NOT NULL,
  `obj_name` char(40) DEFAULT NULL,
  `obj_des` char(40) DEFAULT NULL,
  `obj_type` char(20) DEFAULT NULL,
  `obj_num` char(12) DEFAULT NULL,
  `obj_sw_id` char(12) DEFAULT NULL,
  `obj_sw_grp` char(12) DEFAULT NULL,
  `obj_sw_grpname` char(40) DEFAULT NULL,
  `obj_hf_id` char(20) DEFAULT NULL,
  `obj_hf_grp` char(20) DEFAULT NULL,
  `obj_dmr_id` char(20) DEFAULT NULL,
  `obj_dmr_grp` char(20) DEFAULT NULL,
  `obj_phone` char(20) DEFAULT NULL,
  `obj_hf_grpname` char(40) DEFAULT NULL,
  `obj_dmr_grpname` char(40) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TERMINAL_PHONE` (`TERMINAL_PHONE`)
) ENGINE=InnoDB AUTO_INCREMENT=8307 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `obj_com` WRITE;
/*!40000 ALTER TABLE `obj_com` DISABLE KEYS */;
INSERT INTO `obj_com` VALUES (8288,'412330258','é²å²šæ¸”60016','11','å›½å†…æ•æžèˆ¹','0','1','1','1','1','1','1','1','n','1','1'),(8289,'412328511','é²å²šæ¸”60021','11','å›½å†…æ•æžèˆ¹','0','1','1','1','1','1','1','1','n','1','1'),(8305,'18054311671','é²æ²¾æ¸”62016','123','å›½å†…æ•æžèˆ¹','0','12','6','å±±ä¸œæ¸”ä¸šé•¿å²›ç«™','11','11','12','6334','18054311671','111','å¼€å‘åŒºç»„'),(8306,'412325503','é²å¨æ¸”61668','122','å›½å†…æ•æžèˆ¹','0','1','6','å±±ä¸œæ¸”ä¸šé•¿å²›ç«™','12','11','123','5324','122222','111','åŸŽé˜³åŒºæ¸”ä¸šæ‰§æ³•ç»„');
/*!40000 ALTER TABLE `obj_com` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `obj_gps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obj_gps` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `TERMINAL_PHONE` char(12) NOT NULL,
  `X` char(12) DEFAULT '1',
  `Y` char(12) DEFAULT '1',
  `LOCATION_TIME` char(16) DEFAULT '0',
  `TERMINAL_NAME` char(20) DEFAULT 'TEST',
  `ONOFF` char(2) DEFAULT '0',
  `COURSE` char(8) DEFAULT '0',
  `TRUEHEADING` char(8) DEFAULT '0',
  `SPEED` char(8) DEFAULT '0',
  `TERMINAL_TYPE` char(8) DEFAULT 'ZHIFA',
  `obj_des` char(40) DEFAULT NULL,
  `obj_type` char(20) DEFAULT NULL,
  `obj_name` char(40) DEFAULT NULL,
  `obj_num` char(12) DEFAULT NULL,
  `flg` int(1) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TERMINAL_PHONE` (`TERMINAL_PHONE`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `obj_gps` WRITE;
/*!40000 ALTER TABLE `obj_gps` DISABLE KEYS */;
INSERT INTO `obj_gps` VALUES (24,'412330258','21065484','71624940','1511315163','','0','3410','0','0','ZHIFA','11','ZHIFA','é²å²šæ¸”60016','0',0),(25,'412328511','21031656','71888700','1513082923','','0','1000','0','95','ZHIFA','11','ZHIFA','é²å²šæ¸”60021','0',0),(39,'18054311671','22866638','70941535','1347377646','TEST','0','1040','0','0','ZHIFA','123','ZHIFA','é²æ²¾æ¸”62016','0',0),(40,'412325503','22153518','73488120','1514539526','TEST','0','2870','0','36','ZHIFA','122','ZHIFA','é²å¨æ¸”61668','0',0);
/*!40000 ALTER TABLE `obj_gps` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `obj_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obj_info` (
  `ID` int(4) NOT NULL AUTO_INCREMENT,
  `RN` char(16) DEFAULT NULL,
  `TERMINAL_PHONE` char(12) NOT NULL,
  `X` char(12) DEFAULT NULL,
  `Y` char(12) DEFAULT NULL,
  `LOCATION_TIME` char(16) DEFAULT NULL,
  `TERMINAL_NAME` char(20) DEFAULT NULL,
  `ONOFF` char(2) DEFAULT NULL,
  `COURSE` char(8) DEFAULT NULL,
  `TRUEHEADING` char(8) DEFAULT NULL,
  `SPEED` char(8) DEFAULT NULL,
  `TERMINAL_TYPE` char(8) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `TERMINAL_PHONE` (`TERMINAL_PHONE`)
) ENGINE=InnoDB AUTO_INCREMENT=3550822 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;


LOCK TABLES `obj_info` WRITE;
/*!40000 ALTER TABLE `obj_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `obj_info` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `obj_op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `obj_op` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `usr_id` int(4) DEFAULT NULL,
  `own_id` int(4) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `stat` int(1) DEFAULT NULL,
  `tmp_id` int(4) DEFAULT NULL,
  PRIMARY KEY (`sn`),
  UNIQUE KEY `sn` (`sn`),
  KEY `usr_op` (`usr_id`,`own_id`)
) ENGINE=MyISAM AUTO_INCREMENT=147 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `obj_op` WRITE;
/*!40000 ALTER TABLE `obj_op` DISABLE KEYS */;
/*!40000 ALTER TABLE `obj_op` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `radio_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radio_info` (
  `radio_id` int(12) NOT NULL DEFAULT '0',
  `radio_name` char(20) DEFAULT NULL,
  `radio_des` char(20) DEFAULT NULL,
  `radio_city` char(16) DEFAULT NULL,
  `radio_type` int(1) DEFAULT NULL,
  `radio_stat` int(12) DEFAULT '0',
  `tm` date DEFAULT NULL,
  `radio_cnl` int(2) DEFAULT NULL,
  `device_id` int(16) DEFAULT NULL,
  PRIMARY KEY (`radio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `radio_info` WRITE;
/*!40000 ALTER TABLE `radio_info` DISABLE KEYS */;
INSERT INTO `radio_info` VALUES (9801,'','','',1,0,NULL,0,NULL),(9802,'0','0','0',1,0,NULL,0,NULL);
/*!40000 ALTER TABLE `radio_info` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `radio_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `radio_stat` (
  `radio_id` int(12) NOT NULL DEFAULT '0',
  `radio_stat` int(1) DEFAULT NULL,
  `tm` int(8) DEFAULT NULL,
  PRIMARY KEY (`radio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `radio_stat` WRITE;
/*!40000 ALTER TABLE `radio_stat` DISABLE KEYS */;
INSERT INTO `radio_stat` VALUES (9801,0,NULL),(9802,0,NULL),(9803,0,NULL),(9804,0,NULL),(9805,0,NULL),(9806,0,NULL),(9807,0,NULL);
/*!40000 ALTER TABLE `radio_stat` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `record_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `record_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(64) NOT NULL,
  `pk_sn` int(8) DEFAULT NULL,
  `src_type` int(1) DEFAULT NULL,
  `dst_type` int(1) DEFAULT NULL,
  `src_id` int(12) DEFAULT NULL,
  `dst_id` int(12) DEFAULT NULL,
  `s_tm` int(12) DEFAULT NULL,
  `e_tm` int(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_name` (`file_name`),
  KEY `index_tm` (`s_tm`,`e_tm`)
) ENGINE=InnoDB AUTO_INCREMENT=55950 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `record_info` WRITE;
/*!40000 ALTER TABLE `record_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `record_info` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `usr_au`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usr_au` (
  `usr_id` int(8) NOT NULL DEFAULT '0',
  `radio_id` int(8) NOT NULL DEFAULT '0',
  `radio_type` int(2) DEFAULT '0',
  `usr_au` int(2) DEFAULT '0',
  PRIMARY KEY (`usr_id`,`radio_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `usr_au` WRITE;
/*!40000 ALTER TABLE `usr_au` DISABLE KEYS */;
INSERT INTO `usr_au` VALUES (12362,9803,1,5),(12362,9804,1,5),(12362,9805,1,5),(12362,9806,1,5),(12362,9807,1,5),(12362,8888,7,5),(12362,9002,5,5),(12362,200,6,5),(12362,9013,7,5),(12362,9801,1,5),(12362,9802,1,5),(12362,9901,5,5);
/*!40000 ALTER TABLE `usr_au` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `usr_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usr_info` (
  `usr_id` int(8) DEFAULT NULL,
  `name` char(16) DEFAULT NULL,
  `des` char(20) DEFAULT NULL,
  `tm` date DEFAULT NULL,
  UNIQUE KEY `usr_id` (`usr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `usr_info` WRITE;
/*!40000 ALTER TABLE `usr_info` DISABLE KEYS */;
INSERT INTO `usr_info` VALUES (12362,'admin','³¬¼¶¹ÜÀíÔ±',NULL);
/*!40000 ALTER TABLE `usr_info` ENABLE KEYS */;
UNLOCK TABLES;



DROP TABLE IF EXISTS `usr_passwd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usr_passwd` (
  `usr_id` int(8) DEFAULT NULL,
  `passwd` char(16) DEFAULT NULL,
  `tm` date DEFAULT NULL,
  UNIQUE KEY `usr_id` (`usr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;



LOCK TABLES `usr_passwd` WRITE;
/*!40000 ALTER TABLE `usr_passwd` DISABLE KEYS */;
INSERT INTO `usr_passwd` VALUES (12362,'admin',NULL);
/*!40000 ALTER TABLE `usr_passwd` ENABLE KEYS */;
UNLOCK TABLES;
