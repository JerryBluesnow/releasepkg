#!/bin/bash

CUR_DIR="`dirname $(readlink -f $0)`"
APP_NAME="RadioFunsionServer"
JVM_OPTS="-server -Xms128M -Xmx1G -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -XX:InitiatingHeapOccupancyPercent=45 -XX:+ExplicitGCInvokesConcurrent -Dfile.encoding=utf-8"
APP_OPTS="-jar ${CUR_DIR}/lib/fusionserv.jar --spring.config.name=${APP_NAME} --spring.config.location=${CUR_DIR}/config/application.yaml,${CUR_DIR}/config/application-development.yaml,${CUR_DIR}/config/application-production.yaml --spring.profiles.active=production --logging.config=${CUR_DIR}/config/log4j2-spring.xml"
SIGNAL=${SIGNAL:-TERM}

JAVA_BIN="`which java`"
if [[ "X$JAVA_BIN" = "X" ]]; then
	JAVA_BIN="${JAVA_HOME}/bin/java"
fi

if [[ "X$JAVA_BIN" = "X" ]]; then
	echo "did not found java path."
	exit 1
fi

function check_pid(){
	STOP_ON_ERR=$1
	PIDS=$(ps ax | grep -i "$APP_NAME" | grep java | grep -v grep | awk '{print $1}')
	if [[ "X$PIDS" = "X" && "X$STOP_ON_ERR" = "X1" ]]; then
		echo "Did not found process by process name $APP_NAME"
		exit 1
	fi

	echo $PIDS
}

function print_usage(){
	echo "Usage:"
	echo "$0 start: Start server process in background mode"
	echo "$0 start-block: start server process in blocking mode"
	echo "$0 stop: stop server process"
	echo "$0 info: show server process info"
	echo "$0 restart: restart server"
}

function server_start(){
	PIDS="`check_pid 0`"
	if [[ "X$PIDS" != "X" ]]; then
		echo "Server already started.[$PIDS]"
		exit 1
	fi

	start_mode=$1
	if [[ "$start_mode" = "0" ]]; then
		nohup "$JAVA_BIN" $JVM_OPTS $APP_OPTS >> /dev/null 2>&1 &
	else
		"$JAVA_BIN" $JVM_OPTS $APP_OPTS
	fi
	
	sleep 3s	
	echo "Server PID: `check_pid 0`"
}

function server_stop(){
	PIDS="`check_pid 0`"
	if [[ "X$PIDS" = "X" ]]; then
		echo "Did not found server process by name $APP_NAME, do nothing"
		exit 0
	fi
	
	kill -s $SIGNAL $PIDS
	echo "Server stopped."	
}

function server_info(){
	echo "`ps ax | grep -i "${APP_NAME}" | grep java | grep -v grep`"
}

case $1 in
	"start")
		server_start 0
	;;
	"start-block")
		server_start 1
	;;
	"stop")
		server_stop
	;;
	"restart")
		server_stop
		server_start 0
	;;
	"info")
		server_info
	;;
	*)
		print_usage
	;;
esac
